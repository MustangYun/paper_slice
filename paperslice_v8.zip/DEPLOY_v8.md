# paperslice v8 배포 가이드

## v8에서 바뀐 것

1. **세로쓰기 PDF 감지** — detector가 평균 line당 글자수로 세로쓰기(일본·중국 신문) 자동 판정 → MinerU의 `-m txt` 버그(세로쓰기에서 글자 누락) 회피
2. **`[n/8]` 파이프라인 단계 로그** — 각 단계 완료 시점에 결과값+소요시간 순차 출력
3. **PyMuPDF 의존성 추가** — detector가 실제로 동작하려면 필요
4. **Dockerfile: pip → uv** — 빌드 5~10배 빠름

## zip 안에 든 파일들

```
DEPLOY_v8.md              ← 이 문서
Dockerfile                ← 완성본. 기존 Dockerfile 덮어쓰기
pyproject.toml            ← 완성본. 기존 pyproject.toml 덮어쓰기 (pymupdf 포함됨)
src/paperslice/
  ├── pdf_type_detector.py   ← v8 신규 (세로쓰기 감지 + DetectionResult)
  ├── pipeline.py            ← v8 수정 ([n/8] 단계 로그)
  ├── main.py                ← v7 그대로
  ├── schemas.py             ← v7 그대로
  ├── mineru_runner.py       ← v7 그대로
  └── diff_builder.py        ← v7 그대로
tests/
  ├── test_pdf_type_detector.py   ← v8 수정 (19개 테스트)
  └── test_diff_builder.py        ← v7 그대로
```

## 배포 절차 (PowerShell)

```powershell
# 1. zip 풀기
Expand-Archive -Force C:\Users\User-1\paperslice_v8.zip -DestinationPath C:\Users\User-1\temp_paperslice_v8

# 2. 소스 코드 / 테스트 덮어쓰기
robocopy C:\Users\User-1\temp_paperslice_v8\src\paperslice C:\Users\User-1\paperslice\src\paperslice /E /R:1 /W:1 /NFL /NDL
robocopy C:\Users\User-1\temp_paperslice_v8\tests C:\Users\User-1\paperslice\tests /E /R:1 /W:1 /NFL /NDL

# 3. Dockerfile + pyproject.toml 덮어쓰기 (기존 파일은 자동 백업)
Copy-Item C:\Users\User-1\paperslice\Dockerfile C:\Users\User-1\paperslice\Dockerfile.v7.bak -Force
Copy-Item C:\Users\User-1\paperslice\pyproject.toml C:\Users\User-1\paperslice\pyproject.toml.v7.bak -Force
Copy-Item C:\Users\User-1\temp_paperslice_v8\Dockerfile C:\Users\User-1\paperslice\Dockerfile -Force
Copy-Item C:\Users\User-1\temp_paperslice_v8\pyproject.toml C:\Users\User-1\paperslice\pyproject.toml -Force

# 4. pyproject.toml에 pymupdf 들어갔는지 확인
Select-String -Path C:\Users\User-1\paperslice\pyproject.toml -Pattern "pymupdf"

# 5. 기존 컨테이너·이미지 정리
cd C:\Users\User-1\paperslice
docker ps --filter "publish=8000" --format "{{.ID}}" | ForEach-Object { docker stop $_ }
docker rmi paperslice:latest -f

# 6. rebuild (uv 덕에 빠름)
.\scripts\build.ps1 -CorpCa

# 7. 실행
docker run --rm -p 8000:8000 -v "${PWD}\output:/app/output" paperslice:latest
```

**4번 확인 결과가 이렇게 나와야 함:**
```
pyproject.toml:23:    "pymupdf>=1.24.0",
```

## 검증 포인트

### PyMuPDF가 제대로 설치됐는지

v8 정상 작동 시 로그에 이 줄이 나와야 함:
```
[1/8] PDF 타입 감지 완료 → method=ocr (auto 판별 → 평균 10582자/페이지, 1.1자/line < 5.0 (세로쓰기 의심 — 일본·중국 신문류)) [0.1s]
```

**아래 메시지가 나오면 실패** (이전 이슈 재현):
```
[1/8] PDF 타입 감지 완료 → method=ocr (auto 판별 → PyMuPDF 없음 (fallback)) [0.0s]
```

### 전체 [n/8] 단계 로그 순서

```
Starting parse: document_id=... mode=auto ...
[1/8] PDF 타입 감지 완료 → ...
[2/8] MinerU 실행 완료 → ...
[3/8] Diff 보조 실행 완료 → ...
[4/8] 블록 Enrich 완료 → ...
[5/8] 이미지 저장 완료 → ...
[6/8] 블록 분류 완료 → ...
[7/8] 세그먼트 완료 → ...
[8/8] 응답 조립 완료 → ... [총 ...]
POST /parse 200 OK
```

## 추천 파라미터 조합

**일본 신문 PDF** (화학공업일보 등):
```
file=<pdf>
language=japan
reading_direction=rtl
mode=auto          ← detector가 알아서 ocr 선택
diff_report=false
```

**한국어 논문 / 영문 보고서**:
```
file=<pdf>
language=korean   # 또는 en
reading_direction=ltr
mode=auto          ← detector가 알아서 txt 선택
diff_report=false
```

## 문제 해결

### 빌드 실패: "Invalid statement (at line 1, column 1)"
pyproject.toml에 BOM(UTF-8 Byte Order Mark)이 붙었을 때 나오는 에러. v8 zip의 pyproject.toml은 BOM 없이 생성됨 — 그냥 zip 파일의 것으로 덮어쓰면 문제 없음.

### 빌드 실패: Dockerfile 10단계 근처 에러
```
Error: pymupdf ... not found
```
→ pyproject.toml에 pymupdf 라인이 안 들어간 상태. 4번 단계 `Select-String` 다시 실행해서 확인.

### 컨테이너 안에서 직접 확인
```powershell
docker run --rm paperslice:latest python -c "import fitz; print('PyMuPDF OK')"
```
`PyMuPDF OK` 나오면 설치 완료.

### 되돌리기 (v7로 원복)
```powershell
Copy-Item C:\Users\User-1\paperslice\Dockerfile.v7.bak C:\Users\User-1\paperslice\Dockerfile -Force
Copy-Item C:\Users\User-1\paperslice\pyproject.toml.v7.bak C:\Users\User-1\paperslice\pyproject.toml -Force
```

### 단계별 소요시간 읽기
각 `[X/8]` 뒤의 `[XX.Xs]`로 어디서 시간 많이 쓰는지 바로 보임. MinerU가 전체의 95% 이상이 정상.
